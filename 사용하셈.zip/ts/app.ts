/**
 * ! PR 교육
 * ! 1. 강사 소개
 * ! 1-1 내 프로필 소개
 * ! 1-2 어떤식으로 교육하는지
 * ! 1-3 HTML, CSS, JavaScript 간단 소개.
 * ! 1-4 프론트엔드와 백엔드
 *
 * ? 2. 커리큘럼
 * ? 2-1 HTML 파트
 * ? 2-2 CSS 파트
 * ? 2-3 JS 파트
 *
 * & 3. 이 강의를 들으면 좋은 사람들
 * & 3-1 디자이너
 * & 3-2 퍼블리셔
 * & 3-3 프론트엔드 개발자
 *
 * ^ 3. 취업
 * ^ 3-1 디자이너
 * ^ 3-2 퍼블리셔
 * ^ 3-3 프론트엔드
 */

// console.log(x) // undefined
// var x = 1;
// var x = 3;

// var x;
// console.log(x) // undefined
// x = 1;

import "./animation/barba"
